import { useLocation } from "react-router-dom";
import { Activity, AlertTriangle, Shield, Network, Download, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LineChart, Line, AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import jsPDF from "jspdf";

// Sample data for visualizations
const trafficData = [
  { time: '00:00', packets: 120, icmp: 20, tcp: 70, udp: 30 },
  { time: '00:05', packets: 150, icmp: 25, tcp: 85, udp: 40 },
  { time: '00:10', packets: 2300, icmp: 800, tcp: 1200, udp: 300 },
  { time: '00:15', packets: 2500, icmp: 900, tcp: 1300, udp: 300 },
  { time: '00:20', packets: 180, icmp: 30, tcp: 100, udp: 50 },
  { time: '00:25', packets: 140, icmp: 22, tcp: 80, udp: 38 },
];

const protocolData = [
  { name: 'TCP', value: 45, color: '#06b6d4' },
  { name: 'UDP', value: 25, color: '#22c55e' },
  { name: 'ICMP', value: 30, color: '#a855f7' },
];

const topSourceIPs = [
  { ip: '192.168.1.101', packets: 2300 },
  { ip: '10.0.0.45', packets: 1800 },
  { ip: '172.16.0.23', packets: 1200 },
  { ip: '192.168.1.89', packets: 900 },
  { ip: '10.0.0.12', packets: 600 },
];

const alerts = [
  { id: 1, type: 'SYN Flood', severity: 'high', message: 'Possible SYN Flood detected: 2300 SYN packets in 30s from 192.168.1.101', time: '00:10:23' },
  { id: 2, type: 'UDP Flood', severity: 'medium', message: 'UDP flood from 10.0.0.45 to 172.16.0.1', time: '00:12:45' },
  { id: 3, type: 'ICMP Storm', severity: 'high', message: 'ICMP echo storm detected: 900 packets/sec', time: '00:15:12' },
];

export default function Dashboard() {
  const location = useLocation();
  const files = location.state?.files || [];
  const fileName = files.length > 0 ? files.map((f: any) => f.name).join(', ') : 'sample_traffic.csv';

  const generatePDFReport = () => {
    const doc = new jsPDF();
    
    // Title
    doc.setFontSize(20);
    doc.text("DDoS Attack Analysis Report", 20, 20);
    
    // Date
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 20, 30);
    
    // Files analyzed
    doc.setFontSize(12);
    doc.text("Files Analyzed:", 20, 45);
    doc.setFontSize(10);
    if (files.length > 0) {
      files.forEach((file: any, index: number) => {
        doc.text(`${index + 1}. ${file.name} (${file.protocol})`, 25, 52 + (index * 7));
      });
    } else {
      doc.text(fileName, 25, 52);
    }
    
    // Overview Statistics
    doc.setFontSize(12);
    const statsY = files.length > 0 ? 52 + (files.length * 7) + 10 : 65;
    doc.text("Overview Statistics:", 20, statsY);
    doc.setFontSize(10);
    doc.text(`Total Packets: 6,390`, 25, statsY + 7);
    doc.text(`Duration: 25 minutes`, 25, statsY + 14);
    doc.text(`Active Connections: 42`, 25, statsY + 21);
    doc.text(`Threat Level: High`, 25, statsY + 28);
    
    // Protocol Distribution
    doc.setFontSize(12);
    doc.text("Protocol Distribution:", 20, statsY + 43);
    doc.setFontSize(10);
    doc.text("TCP: 45%", 25, statsY + 50);
    doc.text("UDP: 25%", 25, statsY + 57);
    doc.text("ICMP: 30%", 25, statsY + 64);
    
    // Alerts
    doc.setFontSize(12);
    doc.text("Critical Alerts:", 20, statsY + 79);
    doc.setFontSize(10);
    doc.text("1. Possible SYN Flood detected (High severity)", 25, statsY + 86);
    doc.text("   2,300 SYN packets in 30s from 192.168.1.101", 28, statsY + 93);
    doc.text("2. UDP flood from 10.0.0.45 to 172.16.0.1 (Medium)", 25, statsY + 100);
    doc.text("3. ICMP echo storm detected: 900 packets/sec (High)", 25, statsY + 107);
    
    // Top Source IPs
    doc.setFontSize(12);
    doc.text("Top Source IPs:", 20, statsY + 122);
    doc.setFontSize(10);
    doc.text("1. 192.168.1.101 - 2,300 packets", 25, statsY + 129);
    doc.text("2. 10.0.0.45 - 1,800 packets", 25, statsY + 136);
    doc.text("3. 172.16.0.23 - 1,200 packets", 25, statsY + 143);
    
    // Recommendations
    doc.setFontSize(12);
    doc.text("Recommendations:", 20, statsY + 158);
    doc.setFontSize(10);
    doc.text("- Implement rate limiting for source IP 192.168.1.101", 25, statsY + 165);
    doc.text("- Monitor UDP traffic from 10.0.0.45", 25, statsY + 172);
    doc.text("- Enable SYN cookies on affected servers", 25, statsY + 179);
    doc.text("- Consider blocking ICMP traffic temporarily", 25, statsY + 186);
    
    // Footer
    doc.setFontSize(8);
    doc.text("DDoS Detection System - Confidential Report", 20, 280);
    
    doc.save(`ddos-analysis-report-${new Date().getTime()}.pdf`);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'destructive';
      case 'medium':
        return 'warning';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 lg:px-8">
      <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <div>
          <h1 className="mb-2 text-4xl font-bold">Network Analysis Dashboard</h1>
          <p className="text-muted-foreground">
            {files.length > 0 ? (
              <span>
                Analyzing <span className="font-mono text-primary">{files.length}</span> file(s)
              </span>
            ) : (
              <>Analyzing: <span className="font-mono text-primary">{fileName}</span></>
            )}
          </p>
          {files.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {files.map((file: any, index: number) => (
                <Badge key={index} variant="secondary">
                  <FileText className="mr-1 h-3 w-3" />
                  {file.protocol}
                </Badge>
              ))}
            </div>
          )}
        </div>
        <Button onClick={generatePDFReport}>
          <Download className="mr-2 h-4 w-4" />
          Download PDF Report
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="mb-8 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Packets</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">6,390</div>
            <p className="text-xs text-muted-foreground">+2,300 spike detected</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Duration</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">25 min</div>
            <p className="text-xs text-muted-foreground">Analysis period</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Connections</CardTitle>
            <Network className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-muted-foreground">Unique source IPs</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Threat Level</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">High</div>
            <p className="text-xs text-muted-foreground">3 active alerts</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="mb-8 grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Traffic Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={trafficData}>
                <defs>
                  <linearGradient id="colorPackets" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                <Area type="monotone" dataKey="packets" stroke="#06b6d4" fillOpacity={1} fill="url(#colorPackets)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Protocol Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={protocolData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {protocolData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Protocol Breakdown Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trafficData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="time" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                <Legend />
                <Line type="monotone" dataKey="tcp" stroke="#06b6d4" name="TCP" />
                <Line type="monotone" dataKey="udp" stroke="#22c55e" name="UDP" />
                <Line type="monotone" dataKey="icmp" stroke="#a855f7" name="ICMP" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top Source IPs</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topSourceIPs} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" />
                <YAxis dataKey="ip" type="category" stroke="#94a3b8" width={120} />
                <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155' }} />
                <Bar dataKey="packets" fill="#06b6d4" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Alerts */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Active Alerts & Detections</CardTitle>
          <Shield className="h-5 w-5 text-destructive" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className="flex items-start gap-4 rounded-lg border border-border bg-secondary/30 p-4"
              >
                <AlertTriangle className={`mt-1 h-5 w-5 ${alert.severity === 'high' ? 'text-destructive' : 'text-warning'}`} />
                <div className="flex-1">
                  <div className="mb-2 flex items-center gap-2">
                    <Badge variant={getSeverityColor(alert.severity) as any}>
                      {alert.severity.toUpperCase()}
                    </Badge>
                    <span className="text-sm text-muted-foreground">{alert.time}</span>
                  </div>
                  <h4 className="mb-1 font-semibold">{alert.type}</h4>
                  <p className="text-sm text-muted-foreground">{alert.message}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
