import { Shield, Target, Zap, Code } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function About() {
  return (
    <div className="container mx-auto px-4 py-12 lg:px-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-12 text-center">
          <h1 className="mb-4 text-4xl font-bold">About DDoS Shield</h1>
          <p className="text-lg text-muted-foreground">
            Advanced network traffic analysis and DDoS attack detection system
          </p>
        </div>

        <div className="mb-12 space-y-8">
          <Card className="p-8">
            <div className="mb-4 flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              <h2 className="text-2xl font-bold">What is a DDoS Attack?</h2>
            </div>
            <p className="mb-4 text-muted-foreground">
              A Distributed Denial of Service (DDoS) attack is a malicious attempt to disrupt the normal 
              traffic of a targeted server, service, or network by overwhelming it with a flood of Internet 
              traffic. DDoS attacks achieve effectiveness by utilizing multiple compromised computer systems 
              as sources of attack traffic.
            </p>
            <p className="text-muted-foreground">
              Common types include SYN floods (TCP), UDP floods, and ICMP floods (ping floods), each 
              exploiting different network protocols to exhaust system resources.
            </p>
          </Card>

          <Card className="p-8">
            <div className="mb-4 flex items-center gap-3">
              <Target className="h-8 w-8 text-primary" />
              <h2 className="text-2xl font-bold">How We Detect It</h2>
            </div>
            <div className="space-y-4 text-muted-foreground">
              <p>
                Our system analyzes network packet data to identify patterns and anomalies indicative of 
                DDoS attacks across three main protocols:
              </p>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-4">
                  <h3 className="mb-2 font-semibold text-foreground">ICMP Analysis</h3>
                  <p className="text-sm">
                    Detects ICMP flood attacks by monitoring echo request/reply patterns and packet rates
                  </p>
                </div>
                <div className="rounded-lg border border-success/30 bg-success/5 p-4">
                  <h3 className="mb-2 font-semibold text-foreground">TCP Analysis</h3>
                  <p className="text-sm">
                    Identifies SYN floods and connection exhaustion attacks through TCP flag analysis
                  </p>
                </div>
                <div className="rounded-lg border border-chart-3/30 bg-chart-3/5 p-4">
                  <h3 className="mb-2 font-semibold text-foreground">UDP Analysis</h3>
                  <p className="text-sm">
                    Monitors UDP packet volumes and destination port patterns for flood detection
                  </p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-8">
            <div className="mb-4 flex items-center gap-3">
              <Code className="h-8 w-8 text-primary" />
              <h2 className="text-2xl font-bold">Technologies Used</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="mb-3 font-semibold">Frontend Technologies</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    React with TypeScript for type-safe development
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    Tailwind CSS for modern, responsive styling
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    Recharts for interactive data visualizations
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-primary" />
                    shadcn/ui for beautiful UI components
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="mb-3 font-semibold">Analysis Features</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-success" />
                    Real-time packet analysis algorithms
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-success" />
                    Pattern recognition for attack detection
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-success" />
                    Statistical anomaly detection
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-success" />
                    CSV and PCAP file format support
                  </li>
                </ul>
              </div>
            </div>
          </Card>

          <Card className="p-8">
            <div className="mb-4 flex items-center gap-3">
              <Zap className="h-8 w-8 text-primary" />
              <h2 className="text-2xl font-bold">Project Information</h2>
            </div>
            <div className="space-y-4 text-muted-foreground">
              <p>
                This DDoS Attack Detection System was developed as a comprehensive network security tool 
                to help identify and analyze potential distributed denial of service attacks in network traffic.
              </p>
              <p>
                The system provides security researchers, network administrators, and students with an 
                intuitive interface to understand attack patterns and network behavior through visual 
                analytics and detailed packet inspection capabilities.
              </p>
              <div className="mt-6 rounded-lg border border-border bg-muted/30 p-6">
                <h3 className="mb-4 text-lg font-semibold text-foreground">Key Capabilities</h3>
                <ul className="grid gap-3 md:grid-cols-2">
                  <li className="flex items-start gap-2">
                    <Shield className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
                    <span>Multi-protocol attack detection (ICMP, TCP, UDP)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
                    <span>Real-time traffic visualization</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
                    <span>Intelligent alert system</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <Shield className="mt-0.5 h-5 w-5 flex-shrink-0 text-primary" />
                    <span>Detailed packet inspection</span>
                  </li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
