import { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { Upload as UploadIcon, FileText, X, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";

interface FileInfo {
  name: string;
  size: number;
  type: string;
  protocol?: string;
}

export default function Upload() {
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<FileInfo[]>([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analyzing, setAnalyzing] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const validateFile = (file: File): boolean => {
    const validExtensions = ['.csv', '.pcap', '.pcapng'];
    const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!validExtensions.includes(fileExtension)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a .csv, .pcap, or .pcapng file",
        variant: "destructive",
      });
      return false;
    }
    
    if (file.size > 100 * 1024 * 1024) { // 100MB limit
      toast({
        title: "File too large",
        description: "File size must be less than 100MB",
        variant: "destructive",
      });
      return false;
    }
    
    return true;
  };

  const detectProtocol = (fileName: string): string => {
    const lower = fileName.toLowerCase();
    if (lower.includes('tcp')) return 'TCP';
    if (lower.includes('udp')) return 'UDP';
    if (lower.includes('icmp')) return 'ICMP';
    return 'Unknown';
  };

  const handleFiles = (files: FileList) => {
    const validFiles: FileInfo[] = [];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (validateFile(file)) {
        validFiles.push({
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          protocol: detectProtocol(file.name),
        });
      }
    }

    if (validFiles.length === 0) return;

    setUploadedFiles(prev => [...prev, ...validFiles]);

    // Simulate upload progress
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    toast({
      title: "Files uploaded successfully",
      description: `${validFiles.length} file(s) ready for analysis`,
    });
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };

  const handleAnalyze = () => {
    if (uploadedFiles.length === 0) return;
    
    setAnalyzing(true);
    
    // Simulate analysis
    setTimeout(() => {
      toast({
        title: "Analysis complete",
        description: "Redirecting to dashboard...",
      });
      
      setTimeout(() => {
        navigate('/dashboard', { state: { files: uploadedFiles } });
      }, 1000);
    }, 2000);
  };

  const handleRemoveFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleReset = () => {
    setUploadedFiles([]);
    setUploadProgress(0);
    setAnalyzing(false);
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <div className="container mx-auto px-4 py-12 lg:px-8">
      <div className="mx-auto max-w-3xl">
        <div className="mb-8 text-center">
          <h1 className="mb-4 text-4xl font-bold">Upload Network Data</h1>
          <p className="text-lg text-muted-foreground">
            Upload CSV or PCAP files containing ICMP, TCP, or UDP packet data
          </p>
        </div>

        <Card className="p-8">
          <div
            className={`relative border-2 border-dashed rounded-lg p-12 text-center transition-all ${
              dragActive
                ? "border-primary bg-primary/5"
                : "border-border hover:border-primary/50"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <input
              type="file"
              id="file-upload"
              className="hidden"
              accept=".csv,.pcap,.pcapng"
              onChange={handleChange}
              multiple
            />
            
            <UploadIcon className="mx-auto mb-4 h-16 w-16 text-muted-foreground" />
            
            <h3 className="mb-2 text-xl font-semibold">
              Drag and drop your files here
            </h3>
            
            <p className="mb-6 text-muted-foreground">
              Upload multiple files for batch analysis
            </p>
            
            <Button asChild>
              <label htmlFor="file-upload" className="cursor-pointer">
                Browse Files
              </label>
            </Button>
            
            <p className="mt-6 text-sm text-muted-foreground">
              Supported formats: .csv, .pcap, .pcapng (max 100MB per file)
            </p>
          </div>

          {uploadedFiles.length > 0 && (
            <div className="mt-6 space-y-6">
              <div className="space-y-3">
                <h3 className="font-semibold">Uploaded Files ({uploadedFiles.length})</h3>
                {uploadedFiles.map((file, index) => (
                  <div key={index} className="flex items-start justify-between rounded-lg border border-border bg-secondary/50 p-4">
                    <div className="flex items-start gap-4">
                      <FileText className="mt-1 h-8 w-8 text-primary" />
                      <div>
                        <h4 className="font-semibold">{file.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {formatFileSize(file.size)} • {file.protocol}
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleRemoveFile(index)}
                      disabled={analyzing}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>
                ))}
              </div>

              {uploadProgress < 100 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Uploading...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} />
                </div>
              )}

              {uploadProgress === 100 && !analyzing && (
                <div className="flex items-center gap-2 text-success">
                  <CheckCircle2 className="h-5 w-5" />
                  <span className="font-medium">All files uploaded</span>
                </div>
              )}

              <div className="rounded-lg border border-border bg-muted/30 p-4">
                <h4 className="mb-3 font-semibold">Batch Summary</h4>
                <div className="grid gap-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total files:</span>
                    <span className="font-medium">{uploadedFiles.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total size:</span>
                    <span className="font-medium">
                      {formatFileSize(uploadedFiles.reduce((sum, f) => sum + f.size, 0))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Protocols:</span>
                    <span className="font-medium">
                      {[...new Set(uploadedFiles.map(f => f.protocol))].join(', ')}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={handleAnalyze}
                  disabled={analyzing || uploadProgress < 100}
                  className="flex-1"
                  size="lg"
                >
                  {analyzing ? "Analyzing..." : "Analyze Batch"}
                </Button>
                <Button
                  variant="outline"
                  onClick={handleReset}
                  disabled={analyzing}
                  size="lg"
                >
                  Clear All
                </Button>
              </div>
            </div>
          )}
        </Card>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <Card className="p-4">
            <h4 className="mb-2 font-semibold">Sample Files</h4>
            <p className="text-sm text-muted-foreground">
              Download sample TCP, UDP, and ICMP files to test the system
            </p>
          </Card>
          <Card className="p-4">
            <h4 className="mb-2 font-semibold">Auto-Detection</h4>
            <p className="text-sm text-muted-foreground">
              Automatically detects protocol type from uploaded files
            </p>
          </Card>
          <Card className="p-4">
            <h4 className="mb-2 font-semibold">Fast Analysis</h4>
            <p className="text-sm text-muted-foreground">
              Get results in seconds with our optimized algorithms
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
