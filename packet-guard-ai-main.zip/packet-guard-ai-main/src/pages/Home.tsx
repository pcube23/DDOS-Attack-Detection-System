import { Link } from "react-router-dom";
import { Upload, BarChart3, Shield, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export default function Home() {
  const features = [
    {
      icon: Upload,
      title: "Analyze CSV/PCAP Files",
      description: "Upload network packet captures in CSV or PCAP format for instant analysis",
    },
    {
      icon: BarChart3,
      title: "Real-Time Visualization",
      description: "Interactive charts and graphs showing traffic patterns and anomalies",
    },
    {
      icon: Shield,
      title: "DDoS Detection Alerts",
      description: "Intelligent algorithms detect SYN floods, UDP floods, and ICMP storms",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-background" />
        <div className="container relative mx-auto px-4 lg:px-8">
          <div className="mx-auto max-w-4xl text-center">
            <div className="mb-8 flex justify-center">
              <div className="relative">
                <Shield className="h-24 w-24 text-primary animate-pulse" />
                <div className="absolute inset-0 h-24 w-24 bg-primary/20 blur-3xl" />
              </div>
            </div>
            
            <h1 className="mb-6 text-5xl font-bold tracking-tight lg:text-7xl">
              Detect and Analyze{" "}
              <span className="bg-gradient-primary bg-clip-text text-transparent">
                DDoS Attacks
              </span>{" "}
              in Real-Time
            </h1>
            
            <p className="mb-10 text-xl text-muted-foreground lg:text-2xl">
              Upload your ICMP, TCP, or UDP packet files and let AI-powered analysis
              detect potential threats instantly
            </p>
            
            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Button asChild size="lg" className="gap-2 shadow-glow">
                <Link to="/upload">
                  <Upload className="h-5 w-5" />
                  Upload Now
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/about">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid gap-8 md:grid-cols-3">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="group relative overflow-hidden border-border bg-card p-8 transition-all hover:shadow-glow"
              >
                <div className="mb-4 inline-flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
                  <feature.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="mb-3 text-xl font-bold">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 lg:px-8">
          <Card className="relative overflow-hidden border-primary/50 bg-gradient-to-br from-card to-primary/5 p-12 shadow-glow">
            <div className="relative z-10 mx-auto max-w-2xl text-center">
              <Zap className="mx-auto mb-6 h-12 w-12 text-primary" />
              <h2 className="mb-4 text-3xl font-bold lg:text-4xl">
                Start Analyzing Your Network Traffic
              </h2>
              <p className="mb-8 text-lg text-muted-foreground">
                Get instant insights into potential DDoS attacks with our advanced
                detection system
              </p>
              <Button asChild size="lg" className="gap-2 shadow-lg">
                <Link to="/upload">
                  <Upload className="h-5 w-5" />
                  Get Started
                </Link>
              </Button>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
